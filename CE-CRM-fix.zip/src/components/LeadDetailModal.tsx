import React, { useState } from 'react';
import { 
  X, 
  Calendar, 
  DollarSign, 
  MessageSquare, 
  Clock, 
  TrendingUp, 
  FileText, 
  History,
  CheckCircle2,
  Plus,
  Send,
  Mail,
  Phone,
  ExternalLink,
  Loader2,
  Trash2,
  Download,
  Archive,
  AlertTriangle,
  Edit2,
  AlertCircle
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { Lead, LeadDocument, LeadActivity } from '../types';
import { cn, formatCurrency } from '../lib/utils';
import { supabase } from '../lib/supabase';
import { useAuth } from '../context/AuthContext';
import { useEffect } from 'react';
import { ActivityModal } from './modals/ActivityModal';
import { CatalystMediaViewer } from './CatalystMediaViewer';
import { InventoryCompatibility } from './InventoryCompatibility';
import { formatDistanceToNow } from 'date-fns';
import { es } from 'date-fns/locale';

import { LeadEditForm } from './modals/LeadEditForm';

interface LeadDetailModalProps {
  lead: Lead;
  onClose: () => void;
  onUpdate: (id: string, updates: Partial<Lead>) => Promise<any>;
}

export const LeadDetailModal: React.FC<LeadDetailModalProps> = ({ lead, onClose, onUpdate }) => {
  const { user } = useAuth();
  const [activeTab, setActiveTab] = useState<'timeline' | 'notes' | 'documents'>('timeline');
  const [newNote, setNewNote] = useState('');
  const [documents, setDocuments] = useState<LeadDocument[]>([]);
  const [activities, setActivities] = useState<LeadActivity[]>([]);
  const [isUploading, setIsUploading] = useState(false);
  const [isLoadingDocs, setIsLoadingDocs] = useState(false);
  const [isLoadingActivities, setIsLoadingActivities] = useState(false);
  const [isActivityModalOpen, setIsActivityModalOpen] = useState(false);
  const [isEditModalOpen, setIsEditModalOpen] = useState(false);
  const [viewingFile, setViewingFile] = useState<(LeadDocument & { url: string }) | null>(null);
  const [isGeneratingUrl, setIsGeneratingUrl] = useState(false);
  const [isArchiveModalOpen, setIsArchiveModalOpen] = useState(false);
  const [archiveReason, setArchiveReason] = useState('');
  const [isArchiving, setIsArchiving] = useState(false);
  const [isUpdatingChecklist, setIsUpdatingChecklist] = useState<string | null>(null);
  const [isConfirmingPayment, setIsConfirmingPayment] = useState(false);

  const archiveReasons = [
    { id: 'Converted', label: 'Cliente convertido' },
    { id: 'Ghosting', label: 'Ghosting (Dejó de responder)' },
    { id: 'Price-Drop', label: 'Price-Drop (Presupuesto alto)' },
    { id: 'Timing', label: 'Timing (Interés futuro)' },
    { id: 'Lost', label: 'Lost (Se fue con la competencia)' },
    { id: 'Other', label: 'Otro motivo' }
  ];

  const fetchActivities = async () => {
    if (!lead.id) return;
    setIsLoadingActivities(true);
    try {
      const { data, error } = await supabase
        .from('lead_activities')
        .select('*')
        .eq('lead_id', lead.id)
        .order('created_at', { ascending: false });
      
      if (error) throw error;
      setActivities(data || []);
    } catch (error) {
      console.error('Error fetching activities:', error);
    } finally {
      setIsLoadingActivities(false);
    }
  };

  const fetchDocuments = async () => {
    if (!lead.id) return;
    setIsLoadingDocs(true);
    try {
      const { data, error } = await supabase
        .from('lead_documents')
        .select('*')
        .eq('lead_id', lead.id)
        .order('created_at', { ascending: false });
      
      if (error) throw error;
      setDocuments(data || []);
    } catch (error) {
      console.error('Error fetching documents:', error);
    } finally {
      setIsLoadingDocs(false);
    }
  };

  useEffect(() => {
    if (activeTab === 'documents') {
      fetchDocuments();
    } else if (activeTab === 'timeline') {
      fetchActivities();
    }
  }, [activeTab, lead.id]);

  const handleFileUpload = async (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (!file || !lead.id || !user) return;

    setIsUploading(true);
    try {
      // 1. Subir al Bucket de Supabase Storage
      const fileExt = file.name.split('.').pop();
      const fileName = `${Math.random().toString(36).substring(2)}.${fileExt}`;
      const filePath = `${lead.id}/${Date.now()}_${fileName}`;
      
      const { error: storageError } = await supabase.storage
        .from('client-documents')
        .upload(filePath, file);

      if (storageError) throw storageError;

      // 2. Registrar metadatos en la tabla SQL
      const { error: dbError } = await supabase
        .from('lead_documents')
        .insert([{
          lead_id: lead.id,
          file_name: file.name,
          file_path: filePath,
          file_size: file.size,
          file_type: file.type,
          user_id: user.id
        }]);

      if (dbError) throw dbError;
      
      fetchDocuments();
    } catch (error) {
      console.error('Error uploading file:', error);
      alert('Error al subir el archivo. Asegúrate de que el bucket "client-documents" exista en Supabase.');
    } finally {
      setIsUploading(false);
    }
  };

  const handleDeleteDocument = async (doc: LeadDocument) => {
    if (!confirm('¿Estás seguro de eliminar este documento?')) return;

    try {
      // 1. Eliminar de Storage
      const { error: storageError } = await supabase.storage
        .from('client-documents')
        .remove([doc.file_path]);

      if (storageError) throw storageError;

      // 2. Eliminar de la DB
      const { error: dbError } = await supabase
        .from('lead_documents')
        .delete()
        .eq('id', doc.id);

      if (dbError) throw dbError;

      fetchDocuments();
    } catch (error) {
      console.error('Error deleting document:', error);
    }
  };

  const handleViewFile = async (doc: LeadDocument) => {
    setIsGeneratingUrl(true);
    try {
      const { data, error } = await supabase.storage
        .from('client-documents')
        .createSignedUrl(doc.file_path, 300, { download: false });
      
      if (error) throw error;
      if (data?.signedUrl) {
        setViewingFile({ ...doc, url: data.signedUrl });
      }
    } catch (error) {
      console.error('Error generating signed URL:', error);
    } finally {
      setIsGeneratingUrl(false);
    }
  };

  const handleDownload = async (doc: LeadDocument) => {
    try {
      const { data, error } = await supabase.storage
        .from('client-documents')
        .createSignedUrl(doc.file_path, 60);
      
      if (error) throw error;
      if (data?.signedUrl) {
        window.open(data.signedUrl, '_blank');
      }
    } catch (error) {
      console.error('Error downloading document:', error);
    }
  };

  const handleArchive = async () => {
    if (!archiveReason) return;
    setIsArchiving(true);
    try {
      await onUpdate(lead.id, {
        is_archived: true,
        archive_reason: archiveReason,
        archived_at: new Date().toISOString()
      });
      onClose();
    } catch (error) {
      console.error('Error archiving lead:', error);
    } finally {
      setIsArchiving(false);
    }
  };

  const tabs = [
    { id: 'timeline', label: 'Timeline', icon: History },
    { id: 'notes', label: 'Notas', icon: MessageSquare },
    { id: 'documents', label: 'Documentos', icon: FileText },
  ] as const;

  const SENTIMENTS: Lead['sentiment_label'][] = ['Entusiasta', 'Dudoso', 'Preocupado'];

  const isFinancialConfirmationComplete = 
    lead.payment_confirmed === true && 
    Boolean(lead.contract_signed_at);

  const getPaymentConfirmationLabel = (category: Lead['category']) => {
    if (isFinancialConfirmationComplete && lead.stage === 'Propuesta') {
      return 'Completar cierre';
    }

    if (
      category === 'Proyecto' ||
      category === 'Renta Contenedor' ||
      category === 'Renta Oficina 20 ft'
    ) {
      return '¿Adelanto confirmado?';
    }

    return '¿Pago confirmado?';
  };

  const handleConfirmPayment = async () => {
    if (isConfirmingPayment || lead.stage === 'Cierre') return;

    if (lead.stage !== 'Propuesta') {
      alert('La oportunidad debe estar en Propuesta antes de avanzar a Cierre.');
      return;
    }

    if ((lead.budget || 0) <= 0) {
      alert('Primero debes registrar un presupuesto mayor a $0.');
      return;
    }

    const confirmMessage = isFinancialConfirmationComplete 
      ? '¿Deseas completar el cierre de esta oportunidad?'
      : '¿Confirmas que el pago o adelanto fue recibido? La oportunidad pasará automáticamente a Cierre.';

    if (!window.confirm(confirmMessage)) {
      return;
    }

    setIsConfirmingPayment(true);

    try {
      const updates: Partial<Lead> = isFinancialConfirmationComplete
        ? {
            stage: 'Cierre',
            last_activity: new Date().toISOString()
          }
        : {
            payment_confirmed: true,
            contract_signed_at: lead.contract_signed_at ?? new Date().toISOString(),
            stage: 'Cierre',
            last_activity: new Date().toISOString()
          };

      const updatedLead = await onUpdate(lead.id, updates);

      if (!updatedLead || updatedLead.stage !== 'Cierre') {
        throw new Error('Supabase no confirmó el cambio a Cierre.');
      }
    } catch (error: any) {
      console.error('Error al procesar el cierre:', error);
      alert(error.message || 'No fue posible completar el cierre. Verifica tu conexión.');
    } finally {
      setIsConfirmingPayment(false);
    }
  };

  const handleAddNote = async () => {
    if (!newNote.trim()) return;
    const userName = user?.user_metadata?.full_name || user?.email?.split('@')[0] || 'Usuario';
    const timestamp = new Date().toLocaleString('es-MX', { 
      day: '2-digit', 
      month: '2-digit', 
      year: 'numeric',
      hour: '2-digit',
      minute: '2-digit'
    });
    
    const noteEntry = `[${timestamp} - ${userName}]: ${newNote}`;
    const updatedNotes = lead.ai_notes ? `${lead.ai_notes}\n\n${noteEntry}` : noteEntry;
    
    await onUpdate(lead.id, { ai_notes: updatedNotes });
    setNewNote('');
  };

  const handleConfirmDeposit = async (e: React.MouseEvent) => { 
    e.preventDefault(); 
    e.stopPropagation(); 
  
    // Validación de negocio: No adelanto sin presupuesto 
    if (!lead.budget || lead.budget <= 0) { 
      alert("⚠️ Primero debes definir un presupuesto mayor a $0."); 
      return; 
    } 
  
    const suggestedAmount = (lead.budget * 0.5).toString(); 
    const val = window.prompt("Monto del Adelanto de Depósito (MXN):", suggestedAmount); 
    
    if (val === null) return; 
    const numVal = parseFloat(val.replace(/[^0-9.]/g, '')); 
  
    if (isNaN(numVal) || numVal <= 0) { 
      alert("Ingresa un monto de adelanto válido."); 
      return; 
    } 
  
    try { 
      console.log("Wiring: Registrando adelanto y cerrando...", numVal); 
      // APUNTANDO A LAS COLUMNAS EXACTAS 
      await onUpdate(lead.id, { 
        payment_confirmed: true, 
        monto_anticipo_real: numVal, 
        contract_signed_at: new Date().toISOString(), // Sello de tiempo 
        stage: 'Cierre', // Movimiento automático 
        last_activity: new Date().toISOString()
      }); 
      console.log("Hito financiero registrado y sellado con timestamp en contract_signed_at");
    } catch (error) { 
      console.error("Error en la transacción financiera:", error); 
    } 
  }; 

  const handleUpdateBudget = async (e: React.MouseEvent) => { 
    e.preventDefault(); 
    e.stopPropagation(); // Detiene cualquier interferencia del modal 
  
    const currentBudget = lead.budget?.toString() || "0"; 
    const val = window.prompt("Actualizar Presupuesto Total (MXN):", currentBudget); 
    
    if (val === null) return; 
    const numVal = parseFloat(val.replace(/[^0-9.]/g, '')); 
  
    if (isNaN(numVal)) { 
      alert("Por favor, ingresa un número válido."); 
      return; 
    } 
  
    try { 
      console.log("Wiring: Actualizando presupuesto...", numVal); 
      await onUpdate(lead.id, { budget: numVal }); 
    } catch (err) { 
      console.error("Error en conexión:", err); 
    } 
  }; 

  return (
    <div className="fixed inset-0 z-[100] flex items-center justify-center p-0 md:p-8">
      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        exit={{ opacity: 0 }}
        onClick={onClose}
        className="absolute inset-0 bg-black/80 backdrop-blur-sm"
      />
      
      <motion.div
        initial={{ opacity: 0, scale: 0.95, y: 20 }}
        animate={{ opacity: 1, scale: 1, y: 0 }}
        exit={{ opacity: 0, scale: 0.95, y: 20 }}
        className="relative w-full max-w-5xl h-full md:max-h-[850px] bg-white border border-zinc-200 md:rounded-3xl overflow-hidden flex flex-col shadow-2xl"
      >
        {/* Header */}
        <div className="p-4 md:p-6 border-b border-zinc-100 flex items-center justify-between bg-zinc-50 sticky top-0 z-20 safe-top shrink-0">
          <div className="flex items-center gap-3 md:gap-4">
            <div className="w-11 h-11 md:w-12 md:h-12 bg-zinc-900 rounded-xl md:rounded-2xl flex items-center justify-center text-white font-black text-lg md:text-xl shrink-0">
              {lead.lead_name[0]}
            </div>
            <div className="min-w-0">
              <h2 className="text-base md:text-xl font-black text-zinc-900 tracking-tight truncate max-w-[150px] md:max-w-none">{lead.lead_name}</h2>
              <div className="flex items-center gap-2 md:gap-3 mt-0.5 md:mt-1">
                <span className="text-[9px] font-bold text-zinc-500 uppercase tracking-wider truncate max-w-[80px] md:max-w-none">{lead.project_name}</span>
                <span className="w-1 h-1 bg-zinc-300 rounded-full shrink-0" />
                <span className={cn(
                  "text-[8px] md:text-[10px] font-black uppercase tracking-wider px-2 py-0.5 rounded-lg whitespace-nowrap border",
                  lead.is_archived ? "bg-rose-50 text-rose-500 border-rose-100" :
                  lead.stage === 'Ingreso' ? "bg-blue-50 text-blue-500 border-blue-100" :
                  lead.stage === 'Briefing' ? "bg-amber-50 text-amber-500 border-amber-100" :
                  lead.stage === 'Propuesta' ? "bg-indigo-50 text-indigo-500 border-indigo-100" :
                  "bg-emerald-50 text-emerald-500 border-emerald-100"
                )}>
                  {lead.is_archived ? `Archivado` : lead.stage}
                </span>
              </div>
            </div>
          </div>
          <div className="flex items-center gap-1 md:gap-3">
            <button
              onClick={() => onUpdate(lead.id, { is_priority: !lead.is_priority })}
              className={cn(
                "flex items-center justify-center w-11 h-11 md:w-auto md:px-4 md:py-2 rounded-xl text-xs font-bold transition-all border shadow-sm active:scale-95",
                lead.is_priority 
                  ? "bg-rose-500 text-white border-rose-600 shadow-rose-500/20" 
                  : "bg-white text-zinc-400 border-zinc-200 hover:border-rose-200 hover:text-rose-500"
              )}
            >
              <AlertCircle size={20} className="md:w-[18px]" />
              <span className="hidden md:inline ml-2">{lead.is_priority ? "Prioridad Alta" : "Prioridad"}</span>
            </button>
            <button
              onClick={() => setIsEditModalOpen(true)}
              className="w-11 h-11 flex items-center justify-center hover:bg-zinc-100 rounded-xl text-zinc-400 hover:text-zinc-900 transition-all active:scale-95"
            >
              <Edit2 size={20} />
            </button>
            <button
              onClick={onClose}
              className="w-11 h-11 flex items-center justify-center hover:bg-zinc-100 rounded-xl text-zinc-400 hover:text-zinc-900 transition-all active:scale-95"
            >
              <X size={24} />
            </button>
          </div>
        </div>

        <div className="flex-1 overflow-y-auto md:overflow-hidden flex flex-col md:flex-row pb-32 md:pb-0">
          {/* Left Panel: Info & Stats */}
          <div className="w-full md:w-80 md:border-r border-zinc-100 p-4 md:p-6 space-y-6 md:space-y-8 md:overflow-y-auto bg-zinc-50/50">
            
            {/* SECCIÓN GESTIÓN FINANCIERA */} 
            <div className="space-y-4 pt-2 md:pt-4 border-t md:border-t-0 border-zinc-100"> 
              <h3 className="text-[10px] font-bold text-zinc-500 uppercase tracking-widest">Control de Venta</h3> 
              
              <div className="grid grid-cols-1 gap-3"> 
                {/* Tarjeta de Presupuesto Editable */} 
                <div 
                  onClick={handleUpdateBudget} 
                  className="p-4 bg-white border border-zinc-100 hover:border-emerald-200 rounded-2xl space-y-1 shadow-sm cursor-pointer transition-all group" 
                > 
                  <div className="flex items-center justify-between"> 
                    <div className="flex items-center gap-2 text-emerald-600"> 
                      <TrendingUp size={14} /> 
                      <span className="text-[10px] font-bold uppercase tracking-wider">Presupuesto</span> 
                    </div> 
                    <Plus size={14} className="text-zinc-300 group-hover:text-emerald-500 transition-colors" /> 
                  </div> 
                  <p className="text-xl font-black text-zinc-900"> 
                    {lead.budget ? formatCurrency(lead.budget) : 'Definir Presupuesto'} 
                  </p> 
                </div> 

                {/* Botón de Adelanto / Estado de Pago - DESACTIVADO TEMPORALMENTE 
                {!lead.payment_confirmed ? ( 
                  <button 
                    type="button" 
                    onClick={handleConfirmDeposit} 
                    className={cn( 
                      "w-full py-4 rounded-2xl font-bold flex flex-col items-center justify-center gap-1 transition-all shadow-lg group", 
                      (lead.budget || 0) > 0 
                        ? "bg-emerald-600 hover:bg-emerald-700 text-white shadow-emerald-600/20" 
                        : "bg-zinc-100 text-zinc-400 cursor-not-allowed" 
                    )} 
                  > 
                    <div className="flex items-center gap-2"> 
                      <DollarSign size={18} className="group-hover:scale-110 transition-transform" /> 
                      <span>Confirmar Adelanto</span> 
                    </div> 
                    <span className="text-[9px] opacity-70 uppercase tracking-tighter"> 
                      {(lead.budget || 0) > 0 ? "Click para registrar pago" : "Falta presupuesto"} 
                    </span> 
                  </button> 
                ) : ( 
                  <div className="p-4 bg-emerald-50 border border-emerald-200 rounded-2xl space-y-2"> 
                    <div className="flex items-center justify-between"> 
                      <span className="text-[10px] font-bold text-emerald-600 uppercase font-black">Venta Cerrada</span> 
                      <CheckCircle2 size={16} className="text-emerald-500" /> 
                    </div> 
                    <div className="space-y-0.5"> 
                      <p className="text-[10px] text-emerald-600/70 font-bold uppercase">Adelanto recibido</p> 
                      <p className="text-xl font-black text-emerald-900"> 
                        {formatCurrency(lead.monto_anticipo_real || 0)} 
                      </p> 
                    </div> 
                    {lead.signed_at && ( 
                      <div className="pt-2 border-t border-emerald-100 flex flex-col gap-1">
                        <div className="flex items-center gap-1.5 text-[8px] text-emerald-600/70 font-bold uppercase">
                          <Clock size={10} /> 
                          <span>Fecha de Cierre (Sello ISO)</span>
                        </div>
                        <p className="text-[10px] font-mono text-emerald-800 break-all bg-emerald-100/50 p-1.5 rounded-lg">
                          {lead.signed_at}
                        </p>
                      </div> 
                    )} 
                  </div> 
                )} 
                */}
              </div> 
            </div>

            {/* INFORMACIÓN DE CONTACTO */}
            <div className="space-y-4">
              <h3 className="text-[10px] font-bold text-zinc-500 uppercase tracking-widest">Información de Contacto</h3>
              <div className="space-y-3">
                {lead.email && (
                  <div className="flex items-center gap-3 text-zinc-600">
                    <Mail size={16} />
                    <span className="text-sm truncate">{lead.email}</span>
                  </div>
                )}
                <div className="flex items-center gap-3 text-zinc-600">
                  <Phone size={16} />
                  <span className="text-sm">{lead.phone}</span>
                </div>
                <div className="flex items-center gap-3 text-zinc-600">
                  <Calendar size={16} />
                  <span className="text-sm">Creado: {new Date(lead.created_at || '').toLocaleDateString()}</span>
                </div>
              </div>
            </div>

            {/* RELACIÓN CON INVENTARIO COMPATIBLE */}
            <div className="pt-4 border-t border-zinc-100">
              <InventoryCompatibility 
                productType={lead.category} 
                requiredQuantity={2} // Mock: En el futuro esto vendrá de lead.quantity
              />
            </div>

            {/* 2. ESTADO Y SENTIMIENTO (Botones Blindados) */}
            <div className="space-y-4">
              <h3 className="text-[10px] font-bold text-zinc-500 uppercase tracking-widest">Sentimiento</h3>
              <div className="flex flex-col gap-2">
                {SENTIMENTS.map((s) => (
                  <button 
                    key={s} 
                    type="button"
                    onClick={(e) => {
                      e.stopPropagation();
                      onUpdate(lead.id, { sentiment_label: s });
                    }}
                    className={cn( 
                      "w-full px-4 py-3 min-h-[44px] rounded-xl text-xs font-bold transition-all border flex items-center justify-between group", 
                      lead.sentiment_label === s 
                        ? s === 'Entusiasta' ? "bg-emerald-50 border-emerald-200 text-emerald-700" : 
                          s === 'Dudoso' ? "bg-amber-50 border-amber-200 text-amber-700" : 
                          "bg-rose-50 border-rose-200 text-rose-700" 
                        : "bg-white border-zinc-100 text-zinc-400 hover:border-zinc-300 hover:text-zinc-600" 
                    )} 
                  > 
                    <span>{s}</span> 
                    {lead.sentiment_label === s && <CheckCircle2 size={14} />} 
                  </button> 
                ))} 
              </div>
            </div>

            {/* 3. CHECKLIST DE BRIEFING (Botones Blindados) */}
            <div className="space-y-4">
              <h3 className="text-[10px] font-bold text-zinc-500 uppercase tracking-widest">Checklist de Briefing</h3>
              <div className="space-y-2 bg-white border border-zinc-100 rounded-2xl p-4 shadow-sm">
                {[
                  { id: 'm2', label: 'Metraje (M2) definido' },
                  { id: 'deadlines', label: 'Fechas de entrega' }
                ].map((item) => (
                  <button
                    key={item.id}
                    type="button"
                    disabled={!!isUpdatingChecklist}
                    onClick={(e) => {
              e.stopPropagation();
              const currentChecklist = lead.checklist_briefing || { m2: false, deadlines: false };
              onUpdate(lead.id, {
                checklist_briefing: {
                  ...currentChecklist,
                  [item.id]: !currentChecklist[item.id as keyof typeof currentChecklist]
                }
              });
            }}
            className="w-full flex items-center justify-between group py-3 min-h-[44px] disabled:opacity-50"
          >
            <span className={cn(
              "text-xs font-medium transition-colors",
              lead.checklist_briefing?.[item.id as keyof NonNullable<Lead['checklist_briefing']>]
                ? "text-zinc-900"
                : "text-zinc-400 group-hover:text-zinc-600"
            )}>
              {item.label}
            </span>
            <div className={cn(
              "w-5 h-5 rounded-lg border flex items-center justify-center transition-all",
              lead.checklist_briefing?.[item.id as keyof NonNullable<Lead['checklist_briefing']>]
                ? "bg-indigo-600 border-indigo-600 text-white"
                : "bg-white border-zinc-200 group-hover:border-zinc-300"
            )}>
              {lead.checklist_briefing?.[item.id as keyof NonNullable<Lead['checklist_briefing']>] && <CheckCircle2 size={12} />}
            </div>
          </button>
        ))}
              </div>
            </div>

            {/* 4. CONFIRMACIÓN FINANCIERA */}
            <div className="space-y-4">
              <h3 className="text-[10px] font-bold text-zinc-500 uppercase tracking-widest">
                Confirmación Financiera
              </h3>
              <button
                type="button"
                onClick={(e) => {
                  e.stopPropagation();
                  handleConfirmPayment();
                }}
                disabled={isConfirmingPayment || lead.stage === 'Cierre'}
                className={cn(
                  "w-full p-4 rounded-2xl border-2 transition-all duration-200 flex items-center justify-between shadow-sm group",
                  lead.stage === 'Cierre'
                    ? "bg-emerald-50 border-emerald-200 cursor-not-allowed"
                    : isConfirmingPayment
                      ? "bg-zinc-100 border-zinc-200 text-zinc-400 cursor-wait"
                      : "bg-white border-zinc-200 hover:border-emerald-300 hover:bg-emerald-50/30 cursor-pointer"
                )}
              >
                <div className="flex flex-col items-start gap-1">
                  <span className={cn(
                    "text-sm font-black tracking-tight",
                    lead.stage === 'Cierre' ? "text-emerald-800" :
                    isConfirmingPayment ? "text-zinc-500" :
                    "text-zinc-700 group-hover:text-emerald-700"
                  )}>
                    {lead.stage === 'Cierre' ? 'Venta cerrada' : getPaymentConfirmationLabel(lead.category)}
                  </span>
                  {isFinancialConfirmationComplete && (
                    <span className="text-[10px] font-bold uppercase tracking-widest text-emerald-600">
                      Confirmado
                    </span>
                  )}
                  {isConfirmingPayment && (
                    <span className="text-[10px] font-bold uppercase tracking-widest text-zinc-500 flex items-center gap-1">
                      <Loader2 size={10} className="animate-spin" /> Procesando...
                    </span>
                  )}
                </div>
                <div className={cn(
                  "w-8 h-8 rounded-xl border flex items-center justify-center transition-all",
                  lead.stage === 'Cierre'
                    ? "bg-emerald-500 border-emerald-500 text-white"
                    : isConfirmingPayment
                      ? "bg-zinc-200 border-zinc-200 text-zinc-500"
                      : isFinancialConfirmationComplete
                        ? "bg-emerald-50 border-emerald-300 text-emerald-500 group-hover:bg-emerald-100"
                        : "bg-white border-zinc-300 group-hover:border-emerald-400 group-hover:bg-emerald-100"
                )}>
                  {lead.stage === 'Cierre' ? (
                    <CheckCircle2 size={18} />
                  ) : isConfirmingPayment ? (
                    <Loader2 size={18} className="animate-spin" />
                  ) : (
                    <CheckCircle2 size={18} className={cn(isFinancialConfirmationComplete ? "text-emerald-500" : "text-transparent group-hover:text-emerald-500/50")} />
                  )}
                </div>
              </button>
            </div>

            {/* 5. ACCIONES FINALES (Botones Blindados) */}
            <div className="hidden md:block pt-4 border-t border-zinc-100 space-y-3">
              <button 
                type="button"
                onClick={(e) => {
                  e.stopPropagation();
                  setIsActivityModalOpen(true);
                }}
                className="w-full bg-zinc-900 hover:bg-zinc-800 text-white font-bold py-3 rounded-xl transition-all shadow-lg flex items-center justify-center gap-2"
              >
                <Plus size={18} />
                <span>Nueva Actividad</span>
              </button>
              
              <button 
                type="button"
                onClick={(e) => {
                  e.stopPropagation();
                  setIsArchiveModalOpen(true);
                }}
                className="w-full bg-white border border-zinc-200 hover:bg-rose-50 hover:border-rose-200 text-zinc-500 hover:text-rose-600 font-bold py-3 rounded-xl transition-all flex items-center justify-center gap-2"
              >
                <Archive size={18} />
                <span>Archivar Lead</span>
              </button>
            </div>
          </div>

          {/* Right Panel: Tabs & Content */}
          <div className="flex-1 flex flex-col md:overflow-hidden bg-white">
            <div className="flex items-center gap-6 md:gap-8 px-4 md:px-8 border-b border-zinc-100 sticky top-[73px] md:top-0 z-10 bg-white">
              {tabs.map(tab => (
                <button
                  key={tab.id}
                  onClick={() => setActiveTab(tab.id)}
                  className={cn(
                    "flex items-center gap-2 py-3 md:py-4 min-h-[44px] text-xs md:text-sm font-bold transition-all border-b-2",
                    activeTab === tab.id 
                      ? "text-zinc-900 border-zinc-900" 
                      : "text-zinc-400 border-transparent hover:text-zinc-600"
                  )}
                >
                  <tab.icon size={16} className="md:w-[18px] md:h-[18px]" />
                  {tab.label}
                </button>
              ))}
            </div>

            <div className="flex-1 md:overflow-y-auto p-4 md:p-8">
              <AnimatePresence mode="wait">
                {activeTab === 'timeline' && (
                  <motion.div
                    key="timeline"
                    initial={{ opacity: 0, x: 20 }}
                    animate={{ opacity: 1, x: 0 }}
                    exit={{ opacity: 0, x: -20 }}
                    className="space-y-6 md:space-y-8"
                  >
                    <div className="flex items-center justify-between">
                      <h4 className="text-[10px] md:text-xs font-bold text-zinc-500 uppercase tracking-widest">Historial de Actividad</h4>
                      <button 
                        onClick={() => setIsActivityModalOpen(true)}
                        className="flex items-center gap-2 px-3 py-1.5 md:px-4 md:py-2 bg-zinc-900 hover:bg-zinc-800 text-white text-[10px] md:text-xs font-bold rounded-lg md:rounded-xl transition-all shadow-lg shadow-zinc-900/10"
                      >
                        <Plus size={12} className="md:w-[14px] md:h-[14px]" />
                        <span>Nueva</span>
                      </button>
                    </div>

                    {isLoadingActivities ? (
                      <div className="flex flex-col items-center justify-center py-12 gap-4">
                        <Loader2 className="w-8 h-8 text-zinc-900 animate-spin" />
                        <p className="text-sm text-zinc-500">Cargando historial...</p>
                      </div>
                    ) : activities.length > 0 ? (
                      activities.map((activity) => (
                        <div key={activity.id} className="relative pl-8 border-l border-zinc-100 pb-8 last:pb-0">
                          <div className={cn(
                            "absolute left-[-5px] top-0 w-[9px] h-[9px] rounded-full shadow-sm",
                            activity.type === 'Llamada' ? "bg-blue-500 shadow-blue-500/20" :
                            activity.type === 'WhatsApp' ? "bg-emerald-500 shadow-emerald-500/20" :
                            activity.type === 'Cita' ? "bg-purple-500 shadow-purple-500/20" :
                            activity.type === 'Diseño' ? "bg-pink-500 shadow-pink-500/20" :
                            activity.type === 'Presupuesto' ? "bg-amber-500 shadow-amber-500/20" :
                            "bg-zinc-500 shadow-zinc-500/20"
                          )} />
                          <div className="space-y-2">
                            <div className="flex items-center gap-3">
                              <span className="text-xs font-bold text-zinc-900">{activity.type}</span>
                              <span className="text-[10px] text-zinc-400">
                                {formatDistanceToNow(new Date(activity.created_at), { addSuffix: true, locale: es })}
                              </span>
                            </div>
                            <p className="text-sm text-zinc-600 leading-relaxed">
                              {activity.description}
                            </p>
                          </div>
                        </div>
                      ))
                    ) : (
                      <div className="py-12 text-center bg-zinc-50 border border-dashed border-zinc-200 rounded-2xl">
                        <History className="mx-auto text-zinc-300 mb-3" size={32} />
                        <p className="text-sm text-zinc-500">No hay actividades registradas aún.</p>
                      </div>
                    )}
                  </motion.div>
                )}

                {activeTab === 'notes' && (
                  <motion.div
                    key="notes"
                    initial={{ opacity: 0, x: 20 }}
                    animate={{ opacity: 1, x: 0 }}
                    exit={{ opacity: 0, x: -20 }}
                    className="space-y-6"
                  >
                    <div className="space-y-4">
                      <h4 className="text-xs font-bold text-zinc-500 uppercase tracking-widest">
                        Historial de Notas del Proyecto
                      </h4>
                      {/* Bloque de historial: Ahora en blanco/gris claro */}
                      <div className="bg-zinc-50 border border-zinc-200 p-4 rounded-2xl text-sm text-zinc-700 whitespace-pre-wrap min-h-[250px] max-h-[400px] overflow-y-auto shadow-sm custom-scrollbar">
                        {lead.ai_notes || 'No hay notas registradas para este lead.'}
                      </div>
                    </div>

                    <div className="relative">
                      {/* Textarea: Ahora blanco puro con texto oscuro */}
                      <textarea
                        value={newNote}
                        onChange={(e) => setNewNote(e.target.value)}
                        placeholder="Escribe un comentario o actualización importante..."
                        className="w-full bg-white border border-zinc-200 rounded-2xl p-4 pr-12 text-base md:text-sm text-zinc-900 placeholder:text-zinc-400 focus:outline-none focus:ring-2 focus:ring-indigo-500/20 focus:border-indigo-500 transition-all min-h-[120px] resize-none shadow-sm"
                      />
                      <button 
                        onClick={handleAddNote}
                        disabled={!newNote.trim()}
                        className="absolute right-4 bottom-4 p-2.5 bg-indigo-600 text-white rounded-xl hover:bg-indigo-700 transition-all shadow-lg shadow-indigo-600/30 disabled:opacity-50 disabled:shadow-none"
                      >
                        <Send size={18} />
                      </button>
                    </div>
                  </motion.div>
                )}

                {activeTab === 'documents' && (
                  <motion.div
                    key="documents"
                    initial={{ opacity: 0, x: 20 }}
                    animate={{ opacity: 1, x: 0 }}
                    exit={{ opacity: 0, x: -20 }}
                    className="space-y-6"
                  >
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      {isLoadingDocs ? (
                        <div className="col-span-full flex flex-col items-center justify-center py-12 gap-4">
                          <Loader2 className="w-8 h-8 text-zinc-900 animate-spin" />
                          <p className="text-sm text-zinc-500">Cargando documentos...</p>
                        </div>
                      ) : documents.length > 0 ? (
                        documents.map((doc) => (
                          <div 
                            key={doc.id} 
                            onClick={() => handleViewFile(doc)}
                            className="p-4 bg-white border border-zinc-100 rounded-2xl flex items-center justify-between group hover:border-indigo-500/30 hover:bg-indigo-50/10 transition-all shadow-sm cursor-pointer"
                          >
                            <div className="flex items-center gap-3 overflow-hidden">
                              <div className="w-10 h-10 bg-zinc-50 rounded-xl flex items-center justify-center text-zinc-400 group-hover:text-indigo-600 transition-colors shrink-0">
                                <FileText size={20} />
                              </div>
                              <div className="min-w-0">
                                <p className="text-sm font-bold text-zinc-900 truncate group-hover:text-indigo-900 transition-colors">{doc.file_name}</p>
                                <p className="text-[10px] text-zinc-500">
                                  {(doc.file_size / 1024 / 1024).toFixed(2)} MB • {new Date(doc.created_at).toLocaleDateString()}
                                </p>
                              </div>
                            </div>
                            <div className="flex items-center gap-1" onClick={(e) => e.stopPropagation()}>
                              <button 
                                onClick={() => handleDownload(doc)}
                                className="p-2 text-zinc-400 hover:text-zinc-900 transition-colors"
                                title="Descargar"
                              >
                                <Download size={16} />
                              </button>
                              <button 
                                onClick={() => handleDeleteDocument(doc)}
                                className="p-2 text-zinc-400 hover:text-rose-600 transition-colors"
                                title="Eliminar"
                              >
                                <Trash2 size={16} />
                              </button>
                            </div>
                          </div>
                        ))
                      ) : (
                        <div className="col-span-full py-12 text-center bg-zinc-50 border border-dashed border-zinc-200 rounded-2xl">
                          <FileText className="mx-auto text-zinc-200 mb-3" size={32} />
                          <p className="text-sm text-zinc-500">No hay documentos cargados aún.</p>
                        </div>
                      )}
                    </div>

                    <div className="relative">
                      <input
                        type="file"
                        id="file-upload"
                        className="hidden"
                        onChange={handleFileUpload}
                        disabled={isUploading}
                      />
                      <label
                        htmlFor="file-upload"
                        className={cn(
                          "w-full p-8 border-2 border-dashed border-zinc-100 rounded-2xl flex flex-col items-center justify-center gap-3 transition-all cursor-pointer",
                          isUploading ? "opacity-50 cursor-not-allowed" : "hover:text-zinc-900 hover:border-zinc-200 hover:bg-zinc-50"
                        )}
                      >
                        {isUploading ? (
                          <>
                            <Loader2 className="w-8 h-8 text-zinc-900 animate-spin" />
                            <span className="text-sm font-bold text-zinc-500">Subiendo archivo...</span>
                          </>
                        ) : (
                          <>
                            <div className="w-12 h-12 bg-zinc-50 rounded-2xl flex items-center justify-center text-zinc-400">
                              <Plus size={24} />
                            </div>
                            <div className="text-center">
                              <p className="text-sm font-bold text-zinc-600">Haz clic para subir o arrastra un archivo</p>
                              <p className="text-xs text-zinc-400 mt-1">PDF, Imágenes, Planos (Max 50MB)</p>
                            </div>
                          </>
                        )}
                      </label>
                    </div>
                  </motion.div>
                )}
              </AnimatePresence>
            </div>
          </div>
        </div>

        {/* Mobile Sticky Actions */}
        <div className="md:hidden fixed bottom-0 left-0 right-0 p-4 bg-white/80 backdrop-blur-lg border-t border-zinc-100 flex gap-3 z-30 safe-bottom">
          <button 
            type="button"
            onClick={(e) => {
              e.stopPropagation();
              setIsActivityModalOpen(true);
            }}
            className="flex-1 bg-zinc-900 text-white font-bold py-4 rounded-2xl transition-all shadow-lg flex items-center justify-center gap-2 active:scale-[0.98]"
          >
            <Plus size={20} />
            <span className="text-sm">Actividad</span>
          </button>
          
          <button 
            type="button"
            onClick={(e) => {
              e.stopPropagation();
              setIsArchiveModalOpen(true);
            }}
            className="p-4 bg-white border border-zinc-200 text-zinc-500 rounded-2xl transition-all flex items-center justify-center active:bg-rose-50 active:text-rose-600 active:border-rose-200"
          >
            <Archive size={20} />
          </button>
        </div>
      </motion.div>

      <AnimatePresence>
        {isActivityModalOpen && (
          <ActivityModal
            leadId={lead.id}
            onClose={() => setIsActivityModalOpen(false)}
            onSuccess={() => {
              fetchActivities();
              onUpdate(lead.id, { last_activity: new Date().toISOString() });
            }}
          />
        )}
        {viewingFile && (
          <CatalystMediaViewer 
            file={viewingFile} 
            onClose={() => setViewingFile(null)} 
          />
        )}
        {isEditModalOpen && (
          <LeadEditForm
            lead={lead}
            onClose={() => setIsEditModalOpen(false)}
            onUpdate={onUpdate}
          />
        )}
        {isGeneratingUrl && (
          <motion.div 
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 z-[400] bg-black/20 backdrop-blur-[2px] flex items-center justify-center"
          >
            <div className="bg-white p-6 rounded-2xl shadow-2xl flex items-center gap-4 border border-zinc-100">
              <Loader2 className="w-6 h-6 text-indigo-600 animate-spin" />
              <span className="text-sm font-bold text-zinc-900 uppercase tracking-widest">Generando Acceso Seguro...</span>
            </div>
          </motion.div>
        )}

        {isArchiveModalOpen && (
          <motion.div 
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 z-[500] bg-black/60 backdrop-blur-sm flex items-center justify-center p-4"
          >
            <motion.div 
              initial={{ scale: 0.95, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              className="bg-white w-full max-w-md rounded-3xl overflow-hidden shadow-2xl border border-zinc-100"
            >
              <div className="p-6 border-b border-zinc-50 bg-zinc-50 flex items-center justify-between">
                <div className="flex items-center gap-3 text-rose-600">
                  <Archive size={20} />
                  <h3 className="font-black uppercase tracking-tight">Archivar Lead</h3>
                </div>
                <button onClick={() => setIsArchiveModalOpen(false)} className="text-zinc-400 hover:text-zinc-900">
                  <X size={20} />
                </button>
              </div>
              
              <div className="p-6 space-y-6">
                <div className="p-4 bg-rose-50 border border-rose-100 rounded-2xl flex gap-3">
                  <AlertTriangle className="text-rose-500 shrink-0" size={20} />
                  <p className="text-xs text-rose-700 leading-relaxed">
                    Al archivar este lead, desaparecerá de tu tablero Kanban. Podrás recuperarlo o consultarlo más tarde desde el archivo estratégico.
                  </p>
                </div>

                <div className="space-y-3">
                  <label className="text-[10px] font-bold text-zinc-500 uppercase tracking-widest">Motivo del Archivo (Obligatorio)</label>
                  <div className="grid grid-cols-1 gap-2">
                    {archiveReasons.map((reason) => (
                      <button
                        key={reason.id}
                        onClick={() => setArchiveReason(reason.id)}
                        className={cn(
                          "w-full p-4 rounded-2xl text-left text-sm font-bold transition-all border",
                          archiveReason === reason.id 
                            ? "bg-zinc-900 border-zinc-900 text-white shadow-lg shadow-zinc-900/20" 
                            : "bg-white border-zinc-100 text-zinc-600 hover:border-zinc-300"
                        )}
                      >
                        {reason.label}
                      </button>
                    ))}
                  </div>
                </div>

                <button
                  onClick={handleArchive}
                  disabled={!archiveReason || isArchiving}
                  className="w-full py-4 bg-rose-600 hover:bg-rose-700 disabled:opacity-50 disabled:hover:bg-rose-600 text-white font-black uppercase tracking-widest rounded-2xl transition-all shadow-xl shadow-rose-600/20 flex items-center justify-center gap-2"
                >
                  {isArchiving ? <Loader2 className="animate-spin" size={20} /> : <Archive size={20} />}
                  <span>Confirmar Archivo</span>
                </button>
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
};
