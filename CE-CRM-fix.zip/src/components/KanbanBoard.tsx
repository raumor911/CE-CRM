import React, { useState } from 'react';
import { 
  DndContext, 
  DragEndEvent,
  DragStartEvent,
  PointerSensor, 
  useSensor, 
  useSensors, 
  closestCorners,
  DragOverlay,
  TouchSensor,
  KeyboardSensor
} from '@dnd-kit/core';
import { 
  SortableContext, 
  verticalListSortingStrategy,
  sortableKeyboardCoordinates
} from '@dnd-kit/sortable';
import { useDroppable } from '@dnd-kit/core';
import { Lead } from '../types';
import { LeadCard } from './LeadCard';
import { STAGES } from '../constants';
import { validateLeadClosure } from '../lib/leadClosure';
import { cn } from '../lib/utils';
import { ChevronRight, ChevronLeft, ChevronDown } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';

interface KanbanBoardProps {
  leads: Lead[];
  onUpdateLead: (id: string, updates: Partial<Lead>) => Promise<Lead | null> | void;
  onSelectLead: (lead: Lead) => void;
  activeMobileStage: string;
  onMobileStageChange: (stage: string) => void;
}

const VALID_STAGES = ['Ingreso', 'Briefing', 'Propuesta', 'Cierre'];

const KanbanColumn: React.FC<{
  id: string;
  title: string;
  leads: Lead[];
  onUpdateLead: (id: string, updates: Partial<Lead>) => void;
  onSelectLead: (lead: Lead) => void;
}> = ({ id, title, leads, onUpdateLead, onSelectLead }) => {
  const { setNodeRef, isOver } = useDroppable({ 
    id,
    data: { 
      type: 'column',
      stage: id 
    }
  });

  const getStageColor = (stage: string) => {
    switch (stage) {
      case 'Ingreso': return 'bg-blue-500';
      case 'Briefing': return 'bg-amber-500';
      case 'Propuesta': return 'bg-brand-primary';
      case 'Cierre': return 'bg-emerald-500';
      default: return 'bg-slate-400';
    }
  };

  return (
    <div ref={setNodeRef} className="flex-shrink-0 w-full md:w-80 flex flex-col min-h-[500px]">
      <div className="flex items-center justify-between mb-4 px-2">
        <h3 className="font-black uppercase text-xs text-zinc-400 flex items-center gap-2">
          <span className={cn("w-2 h-2 rounded-full", getStageColor(title))}></span>
          {title}
          <span className={cn(
            "bg-white border border-slate-200 text-slate-500 text-[10px] px-2 py-0.5 rounded-full shadow-sm transition-all duration-300",
            isOver && "animate-pulse ring-2 ring-indigo-400 border-indigo-400 text-indigo-600 scale-110"
          )}>
            {leads.length}
          </span>
        </h3>
      </div>
      
      <div className={cn(
        "flex-1 space-y-3 rounded-xl p-3 border transition-all duration-300",
        isOver 
          ? "bg-indigo-50/50 border-2 border-dashed border-indigo-400 shadow-inner scale-[1.02]" 
          : "bg-slate-100/50 border-slate-200/60"
      )}>
        <SortableContext items={leads.map(l => l.id)} strategy={verticalListSortingStrategy}>
          <div className="flex flex-col gap-3 min-h-[200px]">
            {leads.map((lead) => (
              <LeadCard 
                key={lead.id} 
                lead={lead} 
                onUpdateLead={onUpdateLead} 
                onSelectLead={onSelectLead}
              />
            ))}
          </div>
        </SortableContext>
        
        {leads.length === 0 && !isOver && (
          <div className="py-12 border-2 border-dashed border-slate-200 rounded-xl flex flex-col items-center justify-center text-slate-400 text-xs text-center px-4 gap-2">
            <p>Tu pipeline está despejado.</p>
            <p className="text-[10px] opacity-70 italic">Es buen momento para prospectar.</p>
          </div>
        )}
      </div>
    </div>
  );
};

export const KanbanBoard: React.FC<KanbanBoardProps> = ({ 
  leads, 
  onUpdateLead, 
  onSelectLead,
  activeMobileStage,
  onMobileStageChange
}) => {
  const [activeLead, setActiveLead] = useState<Lead | null>(null);

  const sensors = useSensors(
    useSensor(PointerSensor, { activationConstraint: { distance: 8 } }),
    useSensor(TouchSensor, { activationConstraint: { delay: 250, tolerance: 5 } }),
    useSensor(KeyboardSensor, { coordinateGetter: sortableKeyboardCoordinates })
  );

  const handleDragStart = (event: DragStartEvent) => {
    const { active } = event;
    const lead = leads.find(l => l.id === active.id);
    if (lead) setActiveLead(lead);
  };

  const handleDragEnd = async (event: DragEndEvent) => {
    const { active, over } = event;
    setActiveLead(null);
    
    if (!over) return;

    const activeId = active.id as string;
    const lead = leads.find(l => l.id === activeId);
    if (!lead) return;

    // Determinar la etapa de destino de forma exclusiva desde data.stage
    const newStage = over.data.current?.stage as Lead['stage'] | undefined;

    if (!newStage || !VALID_STAGES.includes(newStage) || lead.stage === newStage) {
      return;
    }

    // Reglas de transición estrictas
    if (newStage === 'Cierre') {
      // Bloquear saltos directos desde Ingreso o Briefing a Cierre
      if (lead.stage === 'Ingreso' || lead.stage === 'Briefing') {
        alert('Esta oportunidad debe avanzar primero a Propuesta antes de poder cerrarse.');
        return;
      }

      // Validar confirmación financiera para el paso Propuesta -> Cierre
      const financialComplete = lead.payment_confirmed === true && Boolean(lead.contract_signed_at);
      
      if (!financialComplete) {
        const validation = validateLeadClosure(lead);

        if (!validation.canClose) {
          alert(
            `Antes de cerrar esta oportunidad completa:\n\n- ${
              validation.missing.join('\n- ')
            }`
          );

          onSelectLead(lead);
          return;
        }
      }
    }

    const updatedLead = await onUpdateLead(activeId, { stage: newStage });

    if (!updatedLead) {
      // Si la actualización falla, no hacemos nada más (la tarjeta se queda donde estaba)
      return;
    }
  };

  const currentStageIndex = STAGES.indexOf(activeMobileStage as any);

  return (
    <DndContext 
      sensors={sensors} 
      collisionDetection={closestCorners} 
      onDragStart={handleDragStart}
      onDragEnd={handleDragEnd}
    >
      {/* Kanban Desktop / List Mobile */}
      <div className="flex md:gap-6 overflow-x-hidden md:overflow-x-auto pb-6 scrollbar-hide px-4 md:px-6 py-4 h-full">
        {/* En desktop mostramos todas */}
        <div className="hidden md:flex gap-6 w-full">
          {STAGES.map((stage) => (
            <KanbanColumn 
              key={stage}
              id={stage}
              title={stage}
              leads={leads.filter(l => l.stage === stage)}
              onUpdateLead={onUpdateLead}
              onSelectLead={onSelectLead}
            />
          ))}
        </div>

        {/* En mobile mostramos una lista plana según la etapa seleccionada */}
        <div className="md:hidden w-full pb-20">
          <div className="flex flex-col gap-4 w-full">
            {leads.length === 0 ? (
              <div className="py-12 border-2 border-dashed border-slate-200 rounded-xl flex flex-col items-center justify-center text-slate-400 text-xs text-center px-4 gap-2">
                <p>No hay oportunidades en esta vista.</p>
                <p className="text-[10px] opacity-70 italic">Modifica los filtros o selecciona otra etapa.</p>
              </div>
            ) : (
              leads.map(lead => (
                <LeadCard 
                  key={lead.id} 
                  lead={lead} 
                  onUpdateLead={onUpdateLead} 
                  onSelectLead={onSelectLead}
                />
              ))
            )}
          </div>
        </div>
      </div>

      <DragOverlay dropAnimation={null}>
        {activeLead ? (
          <LeadCard 
            lead={activeLead} 
            onUpdateLead={() => {}} 
            onSelectLead={() => {}} 
            isOverlay
          />
        ) : null}
      </DragOverlay>
    </DndContext>
  );
};
