import { supabase } from '../../lib/supabase';
import { FinanceCollectedIncomeResult } from '../types';

export const salesIncomeAdapter = {
  async getCollectedSalesIncome(startDate: string, endDate: string): Promise<FinanceCollectedIncomeResult> {
    const { data, error } = await supabase
      .from('leads')
      .select('id, lead_name, project_name, monto_anticipo_real, payment_confirmed, contract_signed_at, budget')
      .eq('payment_confirmed', true)
      .not('contract_signed_at', 'is', null)
      .gte('contract_signed_at', `${startDate}T00:00:00`)
      .lte('contract_signed_at', `${endDate}T23:59:59`)
      .order('contract_signed_at', { ascending: false });

    if (error) throw error;

    const items = (data || [])
      .filter((item: any) => Number(item.monto_anticipo_real || 0) > 0)
      .map((item: any) => ({
        source_id: item.id,
        source_type: 'SALE' as const,
        label: item.project_name ? `${item.lead_name} · ${item.project_name}` : item.lead_name,
        amount: Number(item.monto_anticipo_real || 0),
        collected_at: item.contract_signed_at,
        notes: item.budget && Number(item.budget) > Number(item.monto_anticipo_real || 0)
          ? 'El modelo actual solo registra anticipo cobrado; no existe trazabilidad de cobro total de la venta.'
          : undefined,
      }));

    return {
      items,
      total: items.reduce((sum, item) => sum + item.amount, 0),
      dataGapNotes: [
        'Ventas: solo se contabiliza monto_anticipo_real cuando payment_confirmed = true. No existe todavía un modelo de cobro total por venta.',
      ],
    };
  },
};

export type SalesIncomeAdapter = typeof salesIncomeAdapter;
