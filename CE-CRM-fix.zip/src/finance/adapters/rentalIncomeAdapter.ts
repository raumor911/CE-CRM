import { supabase } from '../../lib/supabase';
import { FinanceCollectedIncomeResult } from '../types';

export const rentalIncomeAdapter = {
  async getCollectedRentalIncome(startDate: string, endDate: string): Promise<FinanceCollectedIncomeResult> {
    const { data, error } = await supabase
      .from('rental_payments')
      .select('id, rental_id, payment_period, expected_amount, confirmed_at, rentals(customer_name, project_name)')
      .eq('status', 'confirmed')
      .not('confirmed_at', 'is', null)
      .gte('confirmed_at', `${startDate}T00:00:00`)
      .lte('confirmed_at', `${endDate}T23:59:59`)
      .order('confirmed_at', { ascending: false });

    if (error) throw error;

    const items = (data || []).map((item: any) => ({
      source_id: item.id,
      source_type: 'RENTAL' as const,
      label: item.rentals?.project_name
        ? `${item.rentals.customer_name} · ${item.rentals.project_name}`
        : item.rentals?.customer_name || item.payment_period,
      amount: Number(item.expected_amount || 0),
      collected_at: item.confirmed_at,
      notes: 'Rentas: el modelo actual confirma cobro sobre expected_amount; no existe campo separado para monto efectivamente cobrado.',
    }));

    return {
      items,
      total: items.reduce((sum, item) => sum + item.amount, 0),
      dataGapNotes: [
        'Rentas: se usa expected_amount de rental_payments confirmados como proxy del cobro, porque aún no hay actual_amount en el modelo.',
      ],
    };
  },
};

export type RentalIncomeAdapter = typeof rentalIncomeAdapter;
