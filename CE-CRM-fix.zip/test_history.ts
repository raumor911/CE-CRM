import { createClient } from '@supabase/supabase-js';
import dotenv from 'dotenv';
dotenv.config();

const supabase = createClient(process.env.VITE_SUPABASE_URL!, process.env.VITE_SUPABASE_ANON_KEY!);

async function run() {
  const { data, error } = await supabase.from('fin_payroll_compensation_history').select('*').limit(1);
  console.log('fin_payroll_compensation_history data:', data, 'error:', error);
}
run();
